# CatatUang — Android MVP v2

Aplikasi pencatat keuangan pribadi offline-first menggunakan Kotlin + Jetpack Compose.

## Fitur
- Dashboard total saldo, pemasukan, pengeluaran, dan ringkasan bulan berjalan.
- Tambah dan edit transaksi.
- Kategori, tanggal transaksi, metode pembayaran, dan catatan.
- Riwayat lengkap dengan pencarian dan filter pemasukan/pengeluaran.
- Laporan bulanan dan pengeluaran per kategori.
- Anggaran bulanan dan indikator penggunaan anggaran.
- Ekspor CSV melalui menu berbagi Android.
- Penyimpanan lokal di perangkat.

## Cara membuat APK dari HP saja (GitHub Actions)
1. Buat akun atau masuk ke GitHub melalui browser.
2. Buat repository baru. Untuk paling mudah, pilih **Public**.
3. Ekstrak ZIP ini jika layanan/ponsel mendukung, lalu unggah isi folder proyek ke repository (pastikan folder `.github/workflows` ikut terunggah).
4. Buka tab **Actions**, pilih **Build CatatUang APK**, lalu tekan **Run workflow**. Jika workflow belum muncul, pastikan file `.github/workflows/build-apk.yml` ada di branch `main`.
5. Tunggu proses selesai dengan tanda hijau.
6. Buka hasil run tersebut dan unduh artifact **CatatUang-debug-apk**. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.
7. Buka APK di HP untuk memasang. Android mungkin meminta izin **Install unknown apps** untuk browser atau aplikasi file manager yang digunakan.

Build memakai GitHub Actions; internet diperlukan saat membangun. Repo publik berarti source code dapat dilihat orang lain, jadi jangan unggah rahasia atau data pribadi. APK debug ini belum ditandatangani sebagai rilis Play Store.

## Cara menjalankan dengan Android Studio
1. Ekstrak ZIP.
2. Buka folder proyek `CatatUangAndroid` lewat Android Studio.
3. Tunggu Gradle Sync selesai.
4. Jalankan ke emulator atau HP Android.

## Catatan
- Data disimpan lokal pada perangkat ini, tidak disinkronkan ke cloud.
- Ekspor CSV membuka menu berbagi Android dengan isi CSV; untuk file CSV tersimpan langsung dapat ditambahkan di versi berikutnya.
- Tanggal dimasukkan dalam format `YYYY-MM-DD`.
- Source code ini belum diverifikasi melalui build di lingkungan Android; jika workflow menemukan error, kirim log error-nya agar bisa diperbaiki.
