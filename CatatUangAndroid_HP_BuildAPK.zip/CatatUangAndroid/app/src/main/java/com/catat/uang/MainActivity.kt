package com.catat.uang

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF17211D)
private val Green = Color(0xFF167D55)
private val Pale = Color(0xFFF3F7F4)
private val Orange = Color(0xFFE88942)
private val Muted = Color(0xFF718078)
private val Blue = Color(0xFF3979C3)
private val Purple = Color(0xFF8065C9)

data class Transaction(
    val id: Long,
    val title: String,
    val amount: Long,
    val category: String,
    val date: String,
    val note: String,
    val isIncome: Boolean,
    val method: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CatatUangApp(this) }
    }
}

private fun rupiah(amount: Long): String =
    NumberFormat.getCurrencyInstance(Locale("in", "ID")).format(amount).replace(",00", "")

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun prettyDate(date: String): String = try {
    SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(
        SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
    )
} catch (_: Exception) { date }

private fun monthKey(date: String) = date.take(7)
private fun monthLabel(date: String): String = try {
    SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(
        SimpleDateFormat("yyyy-MM", Locale.US).parse(date.take(7))!!
    )
} catch (_: Exception) { "Bulan ini" }

private fun loadTransactions(context: Context): List<Transaction> {
    val raw = context.getSharedPreferences("catatuang", Context.MODE_PRIVATE)
        .getString("transactions", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Transaction(
                o.getLong("id"), o.getString("title"), o.getLong("amount"),
                o.getString("category"), o.getString("date"), o.optString("note", ""),
                o.optBoolean("income", false), o.optString("method", "Tunai")
            )
        }.sortedByDescending { it.id }
    } catch (_: Exception) { emptyList() }
}

private fun saveTransactions(context: Context, items: List<Transaction>) {
    val array = JSONArray()
    items.forEach { t ->
        array.put(JSONObject().apply {
            put("id", t.id); put("title", t.title); put("amount", t.amount)
            put("category", t.category); put("date", t.date); put("note", t.note)
            put("income", t.isIncome); put("method", t.method)
        })
    }
    context.getSharedPreferences("catatuang", Context.MODE_PRIVATE)
        .edit().putString("transactions", array.toString()).apply()
}

private fun loadBudget(context: Context): Long =
    context.getSharedPreferences("catatuang", Context.MODE_PRIVATE).getLong("budget", 0L)

private fun saveBudget(context: Context, value: Long) {
    context.getSharedPreferences("catatuang", Context.MODE_PRIVATE).edit().putLong("budget", value).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatatUangApp(context: Context) {
    var transactions by remember { mutableStateOf(loadTransactions(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Transaction?>(null) }
    var incomeMode by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("Semua") }
    var query by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("Beranda") }
    var budget by remember { mutableLongStateOf(loadBudget(context)) }
    var showBudgetDialog by remember { mutableStateOf(false) }

    val month = monthKey(today())
    val monthItems = transactions.filter { monthKey(it.date) == month }
    val income = transactions.filter { it.isIncome }.sumOf { it.amount }
    val expense = transactions.filter { !it.isIncome }.sumOf { it.amount }
    val monthIncome = monthItems.filter { it.isIncome }.sumOf { it.amount }
    val monthExpense = monthItems.filter { !it.isIncome }.sumOf { it.amount }
    val balance = income - expense
    val categoryTotals = monthItems.filter { !it.isIncome }.groupBy { it.category }
        .mapValues { (_, ts) -> ts.sumOf { it.amount } }.toList().sortedByDescending { it.second }
    val shown = transactions.filter { t ->
        (filter == "Semua" || (filter == "Pemasukan" && t.isIncome) || (filter == "Pengeluaran" && !t.isIncome)) &&
            (query.isBlank() || t.title.contains(query, true) || t.category.contains(query, true) ||
                t.note.contains(query, true) || t.method.contains(query, true))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, onPrimary = Color.White, background = Pale,
            surface = Color.White, onSurface = Ink, secondary = Orange
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("CatatUang", fontWeight = FontWeight.Bold, fontSize = 23.sp, color = Ink)
                            Text(
                                when (screen) {
                                    "Laporan" -> "Ringkasan dan analisis"
                                    "Anggaran" -> "Atur batas pengeluaran"
                                    "Transaksi" -> "Semua catatan keuangan"
                                    else -> "Keuangan lebih teratur"
                                },
                                fontSize = 12.sp, color = Muted
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale),
                    actions = {
                        IconButton(onClick = { exportCsv(context, transactions) }) {
                            Icon(Icons.Default.Download, contentDescription = "Ekspor CSV", tint = Green)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf(
                        Triple("Beranda", Icons.Default.Home, "Beranda"),
                        Triple("Transaksi", Icons.Default.ReceiptLong, "Transaksi"),
                        Triple("Laporan", Icons.Default.Assessment, "Laporan"),
                        Triple("Anggaran", Icons.Default.Savings, "Anggaran")
                    ).forEach { (label, icon, destination) ->
                        NavigationBarItem(
                            selected = screen == destination,
                            onClick = { screen = destination },
                            icon = { Icon(icon, contentDescription = null) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (screen == "Beranda" || screen == "Transaksi") {
                    FloatingActionButton(
                        onClick = { editing = null; incomeMode = false; showAdd = true },
                        containerColor = Green, contentColor = Color.White
                    ) { Icon(Icons.Default.Add, contentDescription = "Tambah transaksi") }
                }
            }
        ) { padding ->
            when (screen) {
                "Laporan" -> ReportScreen(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    monthIncome = monthIncome, monthExpense = monthExpense,
                    categoryTotals = categoryTotals, transactions = monthItems
                )
                "Anggaran" -> BudgetScreen(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    budget = budget, spent = monthExpense,
                    onEdit = { showBudgetDialog = true }
                )
                "Transaksi" -> TransactionScreen(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    shown = shown, filter = filter, query = query,
                    onFilter = { filter = it }, onQuery = { query = it },
                    onEdit = { editing = it; incomeMode = it.isIncome; showAdd = true },
                    onDelete = { t ->
                        transactions = transactions.filterNot { it.id == t.id }
                        saveTransactions(context, transactions)
                    }
                )
                else -> HomeScreen(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    balance = balance, income = income, expense = expense,
                    monthIncome = monthIncome, monthExpense = monthExpense,
                    transactions = transactions.take(5),
                    onIncome = { incomeMode = true; editing = null; showAdd = true },
                    onExpense = { incomeMode = false; editing = null; showAdd = true },
                    onSeeAll = { screen = "Transaksi" },
                    onDelete = { t ->
                        transactions = transactions.filterNot { it.id == t.id }
                        saveTransactions(context, transactions)
                    }
                )
            }
        }

        if (showAdd) {
            AddTransactionDialog(
                initial = editing,
                isIncome = incomeMode,
                onDismiss = { showAdd = false; editing = null },
                onSave = { title, amount, category, date, note, method, isIncome ->
                    val old = editing
                    val item = Transaction(
                        old?.id ?: System.currentTimeMillis(), title, amount, category,
                        date, note, isIncome, method
                    )
                    transactions = if (old == null) (listOf(item) + transactions).sortedByDescending { it.id }
                        else transactions.map { if (it.id == old.id) item else it }.sortedByDescending { it.id }
                    saveTransactions(context, transactions)
                    showAdd = false; editing = null
                }
            )
        }

        if (showBudgetDialog) {
            BudgetDialog(
                initial = if (budget > 0) budget.toString() else "",
                onDismiss = { showBudgetDialog = false },
                onSave = { value -> budget = value; saveBudget(context, value); showBudgetDialog = false }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier, balance: Long, income: Long, expense: Long,
    monthIncome: Long, monthExpense: Long, transactions: List<Transaction>,
    onIncome: () -> Unit, onExpense: () -> Unit, onSeeAll: () -> Unit, onDelete: (Transaction) -> Unit
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Green), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("TOTAL SALDO", color = Color.White.copy(alpha = .8f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(rupiah(balance), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryPill("Pemasukan", income, true, Modifier.weight(1f))
                        SummaryPill("Pengeluaran", expense, false, Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Ringkasan bulan ini", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(monthLabel(today()), color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Pemasukan", color = Muted, fontSize = 12.sp)
                            Text(rupiah(monthIncome), color = Green, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Pengeluaran", color = Muted, fontSize = 12.sp)
                            Text(rupiah(monthExpense), color = Orange, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickAction("Pemasukan", Icons.Default.TrendingUp, Modifier.weight(1f), onIncome)
                QuickAction("Pengeluaran", Icons.Default.TrendingDown, Modifier.weight(1f), onExpense)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Transaksi terbaru", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Catatan terakhir kamu", fontSize = 12.sp, color = Muted)
                }
                TextButton(onClick = onSeeAll) { Text("Lihat semua") }
            }
        }
        if (transactions.isEmpty()) {
            item { EmptyState() }
        } else {
            items(transactions, key = { it.id }) { t -> TransactionRow(t, onEdit = {}, onDelete = { onDelete(t) }, compact = true) }
        }
    }
}

@Composable
private fun TransactionScreen(
    modifier: Modifier, shown: List<Transaction>, filter: String, query: String,
    onFilter: (String) -> Unit, onQuery: (String) -> Unit,
    onEdit: (Transaction) -> Unit, onDelete: (Transaction) -> Unit
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari nama, kategori, catatan...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Semua", "Pengeluaran", "Pemasukan").forEach { option ->
                    FilterChip(selected = filter == option, onClick = { onFilter(option) }, label = { Text(option) })
                }
            }
        }
        item { Text("${shown.size} transaksi", color = Muted, fontSize = 12.sp) }
        if (shown.isEmpty()) item { EmptyState() }
        else items(shown, key = { it.id }) { t -> TransactionRow(t, onEdit = { onEdit(t) }, onDelete = { onDelete(t) }) }
    }
}

@Composable
private fun ReportScreen(
    modifier: Modifier, monthIncome: Long, monthExpense: Long,
    categoryTotals: List<Pair<String, Long>>, transactions: List<Transaction>
) {
    val maxValue = categoryTotals.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Laporan bulanan", color = Muted, fontSize = 12.sp)
                    Text(monthLabel(today()), fontWeight = FontWeight.Bold, fontSize = 21.sp)
                    Spacer(Modifier.height(18.dp))
                    ReportLine("Total pemasukan", monthIncome, Green)
                    Spacer(Modifier.height(12.dp))
                    ReportLine("Total pengeluaran", monthExpense, Orange)
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = Pale)
                    Spacer(Modifier.height(12.dp))
                    ReportLine("Selisih bulan ini", monthIncome - monthExpense, Blue)
                }
            }
        }
        item { Text("Pengeluaran per kategori", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (categoryTotals.isEmpty()) {
            item { EmptyState(message = "Belum ada pengeluaran bulan ini.") }
        } else {
            items(categoryTotals, key = { it.first }) { (category, amount) ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(15.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(category, fontWeight = FontWeight.SemiBold)
                            Text(rupiah(amount), fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { (amount.toFloat() / maxValue.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(7.dp),
                            color = if (category == categoryTotals.first().first) Orange else Green,
                            trackColor = Pale
                        )
                    }
                }
            }
        }
        item { Text("${transactions.size} transaksi pada bulan ini", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun BudgetScreen(modifier: Modifier, budget: Long, spent: Long, onEdit: () -> Unit) {
    val fraction = if (budget > 0) (spent.toFloat() / budget).coerceIn(0f, 1f) else 0f
    val remaining = budget - spent
    LazyColumn(modifier, contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Anggaran pengeluaran", color = Muted, fontSize = 12.sp)
                    Text(monthLabel(today()), fontWeight = FontWeight.Bold, fontSize = 21.sp)
                    Spacer(Modifier.height(20.dp))
                    Text("Batas bulanan", color = Muted, fontSize = 12.sp)
                    Text(if (budget > 0) rupiah(budget) else "Belum ditentukan", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    LinearProgressIndicator(
                        progress = { fraction }, modifier = Modifier.fillMaxWidth().height(10.dp),
                        color = if (budget > 0 && spent > budget) Orange else Green, trackColor = Pale
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Terpakai: ${rupiah(spent)}", fontSize = 12.sp, color = Muted)
                        Text(if (budget > 0) "${(fraction * 100).toInt()}%" else "0%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        when {
                            budget <= 0 -> "Atur anggaran supaya pengeluaran lebih terkontrol."
                            remaining < 0 -> "Anggaran terlampaui ${rupiah(-remaining)}."
                            remaining == 0L -> "Anggaran sudah terpakai seluruhnya."
                            else -> "Sisa anggaran ${rupiah(remaining)}."
                        },
                        color = if (budget > 0 && remaining < 0) Orange else Ink
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("Atur anggaran") }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Category, contentDescription = null, tint = Green, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Tips anggaran", fontWeight = FontWeight.Bold)
                        Text("Tetapkan batas realistis berdasarkan kebutuhan bulanan dan tinjau pengeluaran secara rutin.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryPill(label: String, amount: Long, positive: Boolean, modifier: Modifier = Modifier) {
    Row(modifier.background(Color.White.copy(alpha = .13f), RoundedCornerShape(15.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).background(Color.White.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(if (positive) Icons.Default.TrendingUp else Icons.Default.TrendingDown, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, color = Color.White.copy(alpha = .78f), fontSize = 11.sp)
            Text(rupiah(amount), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.height(54.dp), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(horizontal = 6.dp)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
private fun TransactionRow(t: Transaction, onEdit: () -> Unit, onDelete: () -> Unit, compact: Boolean = false) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(
            Modifier.fillMaxWidth().clickable { onEdit() }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(44.dp).background(if (t.isIncome) Color(0xFFE2F4E9) else Color(0xFFFFEEE2), CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (t.isIncome) Icons.Default.ArrowDownward else Icons.Default.ReceiptLong, contentDescription = null, tint = if (t.isIncome) Green else Orange)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 15.sp)
                Text("${t.category} • ${prettyDate(t.date)}", color = Muted, fontSize = 11.sp)
                if (!compact || t.note.isNotBlank()) Text(
                    listOf(t.method, t.note).filter { it.isNotBlank() }.joinToString(" · "),
                    color = Muted, fontSize = 11.sp, maxLines = 2
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (t.isIncome) "+" else "−") + rupiah(t.amount), color = if (t.isIncome) Green else Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                IconButton(onClick = onDelete, modifier = Modifier.size(27.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus transaksi", tint = Muted, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun ReportLine(label: String, amount: Long, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 13.sp)
        Text(rupiah(amount), color = color, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun EmptyState(message: String = "Tekan tombol + untuk mulai mencatat.") {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Savings, contentDescription = null, tint = Green, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(10.dp))
            Text("Belum ada transaksi", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(message, color = Muted, fontSize = 13.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(
    initial: Transaction?,
    isIncome: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Long, String, String, String, String, Boolean) -> Unit
) {
    var title by remember(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var amountText by remember(initial?.id) { mutableStateOf(initial?.amount?.toString() ?: "") }
    var category by remember(initial?.id) { mutableStateOf(initial?.category ?: if (isIncome) "Gaji" else "Makanan") }
    var date by remember(initial?.id) { mutableStateOf(initial?.date ?: today()) }
    var note by remember(initial?.id) { mutableStateOf(initial?.note ?: "") }
    var method by remember(initial?.id) { mutableStateOf(initial?.method ?: "Tunai") }
    var expanded by remember { mutableStateOf(false) }
    var methodExpanded by remember { mutableStateOf(false) }
    val categories = if (isIncome) listOf("Gaji", "Bonus", "Usaha", "Investasi", "Hadiah", "Lainnya")
        else listOf("Makanan", "Transportasi", "Belanja", "Tagihan", "Tempat tinggal", "Kesehatan", "Hiburan", "Pendidikan", "Keluarga", "Trading", "Bahan bakar", "Lainnya")
    val amount = amountText.toLongOrNull() ?: 0L
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial != null) "Edit transaksi" else if (isIncome) "Tambah pemasukan" else "Tambah pengeluaran", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, placeholder = { Text("Contoh: makan siang") }, singleLine = true)
                OutlinedTextField(amountText, { amountText = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, placeholder = { Text("25000") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth(), singleLine = true)
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { category = item; expanded = false }) }
                    }
                }
                OutlinedTextField(date, { date = it }, label = { Text("Tanggal (YYYY-MM-DD)") }, placeholder = { Text("2026-10-10") }, singleLine = true)
                ExposedDropdownMenuBox(expanded = methodExpanded, onExpandedChange = { methodExpanded = !methodExpanded }) {
                    OutlinedTextField(method, {}, readOnly = true, label = { Text("Metode pembayaran") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth(), singleLine = true)
                    ExposedDropdownMenu(expanded = methodExpanded, onDismissRequest = { methodExpanded = false }) {
                        listOf("Tunai", "Transfer bank", "QRIS", "E-wallet", "Kartu debit", "Kartu kredit", "Lainnya").forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = { method = item; methodExpanded = false })
                        }
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, placeholder = { Text("Detail tambahan") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isNotBlank() && amount > 0 && date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                    onSave(title.trim(), amount, category, date, note.trim(), method, isIncome)
                }
            }, enabled = title.isNotBlank() && amount > 0 && date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun BudgetDialog(initial: String, onDismiss: () -> Unit, onSave: (Long) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Atur anggaran bulanan") },
        text = {
            OutlinedTextField(
                value, { value = it.filter(Char::isDigit) },
                label = { Text("Batas pengeluaran (Rp)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
        },
        confirmButton = { Button(onClick = { onSave(value.toLongOrNull() ?: 0L) }, enabled = value.toLongOrNull() != null) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

private fun exportCsv(context: Context, transactions: List<Transaction>) {
    val header = "Tanggal,Nama,Jenis,Kategori,Nominal,Metode,Catatan"
    val rows = transactions.map { t ->
        listOf(t.date, t.title, if (t.isIncome) "Pemasukan" else "Pengeluaran", t.category, t.amount.toString(), t.method, t.note)
            .joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" }
    }
    val csv = (listOf(header) + rows).joinToString("\n")
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_SUBJECT, "Laporan CatatUang")
        putExtra(Intent.EXTRA_TEXT, csv)
    }
    try { context.startActivity(Intent.createChooser(intent, "Ekspor laporan CatatUang")) } catch (_: Exception) {}
}
